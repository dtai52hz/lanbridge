#include <stdio.h>
#include <stdlib.h>
#include <uiohook.h>

#ifdef _WIN32
#include <windows.h>
#define sleep(x) Sleep(1000 * (x))
#else
#include <unistd.h>
#endif

// Virtual event pointers
static uiohook_event *event = NULL;


static void logger_proc(unsigned int level, void *user_data, const char *format, va_list args) {
    switch (level) {
        case LOG_LEVEL_INFO:
            vfprintf(stdout, format, args);
            break;

        case LOG_LEVEL_WARN:
        case LOG_LEVEL_ERROR:
            vfprintf(stderr, format, args);
            break;
    }
}

static void logger(unsigned int level, const char *format, ...) {
    va_list args;

    va_start(args, format);
    logger_proc(level, NULL, format, args);
    va_end(args);
}

// TODO Implement CLI options.
//int main(int argc, char *argv[]) {
int main() {
    // Set the logger callback for library output.
    hook_set_logger_proc(&logger_proc, NULL);

    // Allocate memory for the virtual events only once.
    event = (uiohook_event *) malloc(sizeof(uiohook_event));
    if (event == NULL) {
        return UIOHOOK_ERROR_OUT_OF_MEMORY;
    }

    // Initialize the virtual devices used for event simulation.
    int status = hook_init_virtual_devices("uiohook demo");
    if (status != UIOHOOK_SUCCESS) {
        logger(LOG_LEVEL_ERROR, "Failed to initialize the virtual devices! (%#X)\n", status);

        free(event);
        return status;
    }

    sleep(1);

    //* Move the mouse cursor in a square shape relative to the current mouse position.
    // Affected by dpi on Windows.
    event->type = EVENT_MOUSE_MOVED_RELATIVE;
    event->data.mouse.x = 0;
    event->data.mouse.y = 100;
    hook_post_event(event);

    sleep(1);

    event->data.mouse.x = 100;
    event->data.mouse.y = 0;
    hook_post_event(event);

    sleep(1);

    event->data.mouse.x = 0;
    event->data.mouse.y = -100;
    hook_post_event(event);

    sleep(1);

    event->data.mouse.x = -100;
    event->data.mouse.y = 0;
    hook_post_event(event);
    //*/

    sleep(1);

    //* Right mouse button click at current mouse location
    event->type = EVENT_MOUSE_PRESSED_IGNORE_COORDS;
    event->data.mouse.button = MOUSE_BUTTON2;
    hook_post_event(event);

    event->type = EVENT_MOUSE_RELEASED_IGNORE_COORDS;
    hook_post_event(event);
    //*/

    sleep(1);

    //* Click drag example
    event->type = EVENT_MOUSE_PRESSED;
    event->data.mouse.button = MOUSE_BUTTON1;
    #ifdef _WIN32
    event->data.mouse.x = 4;
    event->data.mouse.y = 4;
    #else
    event->data.mouse.x = 10;
    event->data.mouse.y = 35;
    #endif
    hook_post_event(event);

    sleep(1);

    for (int i = 0; i < 275; i++) {
        event->type = EVENT_MOUSE_MOVED;
        event->data.mouse.button = MOUSE_NOBUTTON;
        event->data.mouse.x = i;
        event->data.mouse.y = i;
        hook_post_event(event);
    }

    sleep(1);

    event->type = EVENT_MOUSE_RELEASED;
    event->data.mouse.button = MOUSE_BUTTON1;
    hook_post_event(event);

    sleep(1);

    event->type = EVENT_KEY_PRESSED;
    event->mask = 0x00;
    event->data.keyboard.keychar = CHAR_UNDEFINED;
    event->data.keyboard.keycode = VC_ESCAPE;
    hook_post_event(event);
    //*/

    //* Key press with modifier example
    event->type = EVENT_KEY_PRESSED;
    event->mask = 0x00;
    event->data.keyboard.keychar = CHAR_UNDEFINED;

    event->data.keyboard.keycode = VC_SHIFT_L;
    hook_post_event(event);

    event->data.keyboard.keycode = VC_A;
    hook_post_event(event);


    event->type = EVENT_KEY_RELEASED;

    event->data.keyboard.keycode = VC_A;
    hook_post_event(event);

    event->data.keyboard.keycode = VC_SHIFT_L;
    hook_post_event(event);
    //*/

    //* Mouse Wheel Event
    event->type = EVENT_MOUSE_WHEEL;

    event->data.wheel.x = 675;
    event->data.wheel.y = 675;
    event->data.wheel.type = WHEEL_UNIT_SCROLL;
    event->data.wheel.direction = WHEEL_VERTICAL_DIRECTION;
    event->data.wheel.rotation = 360;
    event->data.wheel.delta = 120;
    hook_post_event(event);
    //*/

    free(event);

    return hook_destroy_virtual_devices();
}
