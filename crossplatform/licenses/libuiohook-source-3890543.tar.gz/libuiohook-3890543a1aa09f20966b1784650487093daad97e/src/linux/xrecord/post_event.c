#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <uiohook.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/XTest.h>
#include <xkbcommon/xkbcommon.h>

#include "input_helper.h"
#include "logger.h"

// A wheel click is 120 units of rotation, which is the same unit as WHEEL_DELTA on Windows.
#define WHEEL_DELTA 120

static uint64_t post_text_delay = 50 * 1000000;

uint64_t hook_get_post_text_delay_linux() {
    return post_text_delay;
}

void hook_set_post_text_delay_linux(uint64_t delay) {
    post_text_delay = delay;
}

static int post_key_event(uiohook_event * const event) {
    load_key_mappings();
    KeyCode keycode = uiocode_to_keycode(event->data.keyboard.keycode);
    if (keycode == 0x0000) {
        logger(LOG_LEVEL_WARN, "%s [%u]: Unable to lookup scancode: %li\n",
                __FUNCTION__, __LINE__, event->data.keyboard.keycode);
        return UIOHOOK_FAILURE;
    }

    Bool is_pressed;
    if (event->type == EVENT_KEY_PRESSED) {
        is_pressed = True;
    } else if (event->type == EVENT_KEY_RELEASED) {
        is_pressed = False;
    } else {
        logger(LOG_LEVEL_DEBUG, "%s [%u]: Invalid event for keyboard post event: %#X.\n",
                __FUNCTION__, __LINE__, event->type);
        return UIOHOOK_FAILURE;
    }

    if (!XTestFakeKeyEvent(helper_disp, keycode, is_pressed, 0)) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: XTestFakeKeyEvent() failed!\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_FAILURE;
    }

    return UIOHOOK_SUCCESS;
}

static unsigned int map_to_x11_mouse_button(uint16_t button) {
    switch (button) {
        case MOUSE_BUTTON1:
            return Button1;
        case MOUSE_BUTTON2:
            return Button3; // Apparently, when simulating mouse events, the right button is actually button 3,
        case MOUSE_BUTTON3:
            return Button2; // and the middle button is actually button 2
        case MOUSE_BUTTON4:
            return XButton1;
        case MOUSE_BUTTON5:
            return XButton2;
    }

    return 0;
}

static int post_mouse_button_event(uiohook_event * const event) {
    XButtonEvent btn_event = {
        .serial = 0,
        .send_event = False,
        .display = helper_disp,

        .window = None,                                /* “event” window it is reported relative to */
        .root = None,                                  /* root window that the event occurred on */
        .subwindow = XDefaultRootWindow(helper_disp),  /* child window */

        .time = CurrentTime,

        .x = event->data.mouse.x,                      /* pointer x, y coordinates in event window */
        .y = event->data.mouse.y,

        .x_root = 0,                                   /* coordinates relative to root */
        .y_root = 0,

        .state = 0x00,                                 /* key or button mask */
        .same_screen = True
    };

    if (!(event->type == EVENT_MOUSE_PRESSED_IGNORE_COORDS || event->type == EVENT_MOUSE_RELEASED_IGNORE_COORDS)) {
        // Move the pointer to the specified position.
        XTestFakeMotionEvent(btn_event.display, -1, btn_event.x, btn_event.y, 0);
    }

    int status = UIOHOOK_FAILURE;
    switch (event->type) {
        case EVENT_MOUSE_PRESSED:
        case EVENT_MOUSE_PRESSED_IGNORE_COORDS:
            if (event->data.mouse.button < MOUSE_BUTTON1 || event->data.mouse.button > MOUSE_BUTTON5) {
                logger(LOG_LEVEL_WARN, "%s [%u]: Invalid button specified for mouse pressed event! (%u)\n",
                        __FUNCTION__, __LINE__, event->data.mouse.button);
                return UIOHOOK_FAILURE;
            }

            if (XTestFakeButtonEvent(helper_disp, map_to_x11_mouse_button(event->data.mouse.button), True, 0) != 0) {
                status = UIOHOOK_SUCCESS;
            }
            break;

        case EVENT_MOUSE_RELEASED:
        case EVENT_MOUSE_RELEASED_IGNORE_COORDS:
            if (event->data.mouse.button < MOUSE_BUTTON1 || event->data.mouse.button > MOUSE_BUTTON5) {
                logger(LOG_LEVEL_WARN, "%s [%u]: Invalid button specified for mouse released event! (%u)\n",
                        __FUNCTION__, __LINE__, event->data.mouse.button);
                return UIOHOOK_FAILURE;
            }

            if (XTestFakeButtonEvent(helper_disp, map_to_x11_mouse_button(event->data.mouse.button), False, 0) != 0) {
                status = UIOHOOK_SUCCESS;
            }
            break;

        default:
            logger(LOG_LEVEL_DEBUG, "%s [%u]: Invalid mouse button event: %#X.\n",
                    __FUNCTION__, __LINE__, event->type);
            status = UIOHOOK_FAILURE;
    }

    return status;
}

static int post_mouse_wheel_event(uiohook_event * const event) {
    bool horizontal = event->data.wheel.direction == WHEEL_HORIZONTAL_DIRECTION;

    int32_t clicks = event->data.wheel.rotation / WHEEL_DELTA;
    if (clicks == 0) {
        return UIOHOOK_SUCCESS;
    }

    uint8_t wheel_button;
    if (horizontal) {
        wheel_button = clicks > 0 ? WheelLeft : WheelRight;
    } else {
        wheel_button = clicks > 0 ? WheelUp : WheelDown;
    }

    unsigned int button = button_map_lookup(wheel_button);

    for (int32_t i = 0; i < abs(clicks); i++) {
        if (XTestFakeButtonEvent(helper_disp, button, True, 0) == 0
                || XTestFakeButtonEvent(helper_disp, button, False, 0) == 0) {
            logger(LOG_LEVEL_ERROR, "%s [%u]: XTestFakeButtonEvent() failed!\n",
                    __FUNCTION__, __LINE__);
            return UIOHOOK_FAILURE;
        }
    }

    return UIOHOOK_SUCCESS;
}

static int post_mouse_motion_event(uiohook_event * const event) {
    int status = UIOHOOK_FAILURE;

    if (event->type == EVENT_MOUSE_MOVED_RELATIVE || event->type == EVENT_MOUSE_DRAGGED_RELATIVE) {
        Window window;
        int x, y;
        unsigned int mask;
        if (XQueryPointer(helper_disp, XDefaultRootWindow(helper_disp), &window, &window, &x, &y, &x, &y, &mask) != 0) {
            if (XTestFakeMotionEvent(helper_disp, -1, x + event->data.mouse.x, y + event->data.mouse.y, 0) != 0) {
                status = UIOHOOK_SUCCESS;
            }
        }
    } else {
        if (XTestFakeMotionEvent(helper_disp, -1, event->data.mouse.x, event->data.mouse.y, 0) != 0) {
            status = UIOHOOK_SUCCESS;
        }
    }

    return status;
}

int hook_post_event(uiohook_event * const event) {
    return hook_post_events(event, 1);
}

int hook_post_events(uiohook_event * const events, uint32_t size) {
    if (helper_disp == NULL) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: XDisplay helper_disp is unavailable!\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_ERROR_X_OPEN_DISPLAY;
    }

    if (events == NULL) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: Not simulating any events as the events are null.\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_ERROR_NULL;
    }

    if (size == 0) {
        logger(LOG_LEVEL_WARN, "%s [%u]: Not simulating any events as the size is 0.\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_SUCCESS;
    }

    XLockDisplay(helper_disp);

    int status = UIOHOOK_SUCCESS;

    for (int i = 0; i < size && status == UIOHOOK_SUCCESS; i++) {
        uiohook_event *event = events + i;

        switch (event->type) {
            case EVENT_KEY_PRESSED:
            case EVENT_KEY_RELEASED:
                status = post_key_event(event);
                break;

            case EVENT_MOUSE_PRESSED:
            case EVENT_MOUSE_RELEASED:
            case EVENT_MOUSE_PRESSED_IGNORE_COORDS:
            case EVENT_MOUSE_RELEASED_IGNORE_COORDS:
                status = post_mouse_button_event(event);
                break;

            case EVENT_MOUSE_WHEEL:
                status = post_mouse_wheel_event(event);
                break;

            case EVENT_MOUSE_MOVED:
            case EVENT_MOUSE_DRAGGED:
            case EVENT_MOUSE_MOVED_RELATIVE:
            case EVENT_MOUSE_DRAGGED_RELATIVE:
                status = post_mouse_motion_event(event);
                break;

            case EVENT_KEY_TYPED:
            case EVENT_MOUSE_CLICKED:

            case EVENT_HOOK_ENABLED:
            case EVENT_HOOK_DISABLED:

            default:
                logger(LOG_LEVEL_WARN, "%s [%u]: Ignoring post event type %#X\n",
                        __FUNCTION__, __LINE__, event->type);
                status = UIOHOOK_FAILURE;
                break;
        }
    }

    XSync(helper_disp, True);
    XUnlockDisplay(helper_disp);

    return status;
}

int is_surrogate(uint16_t uc) {
    return (uc - 0xD800U) < 2048U;
}

int is_high_surrogate(uint16_t uc) {
    return (uc & 0xFFFFFC00) == 0xD800;
}

int is_low_surrogate(uint16_t uc) {
    return (uc & 0xFFFFFC00) == 0xDC00;
}

uint32_t surrogate_to_utf32(uint16_t high, uint16_t low) {
    return (high << 10) + low - 0x35FDC00;
}

uint32_t *convert_utf16_to_utf32(const uint16_t * input, size_t count) {
    const uint16_t * const end = input + count;
    uint32_t *result = (uint32_t*)calloc(count + 1, sizeof(uint32_t));
    uint32_t *output = result;

    while (input < end) {
        const uint16_t uc = *input++;
        if (!is_surrogate(uc)) {
            *output++ = uc;
        } else {
            *output++ = is_high_surrogate(uc) && input < end && is_low_surrogate(*input)
                ? surrogate_to_utf32(uc, *input++)
                : 0xFFFD;
        }
    }

    return result;
}

KeySym *map_to_keysyms(const uint16_t * const text, size_t count, size_t *keysym_count) {
    uint32_t *utf32_text = convert_utf16_to_utf32(text, count);

    KeySym *keysyms = (KeySym*)calloc(count, sizeof(KeySym));

    size_t i = 0;
    for (; utf32_text[i] != 0; i++) {
        keysyms[i] = xkb_utf32_to_keysym(utf32_text[i]);

        if (keysyms[i] == NoSymbol) {
            logger(LOG_LEVEL_WARN, "%s [%u]: Could not map character %04X to a key sym!\n",
                __FUNCTION__, __LINE__, utf32_text[i]);
        }
    }

    *keysym_count = i;
    free(utf32_text);

    return keysyms;
}

KeyCode find_unused_keycode() {
    int min_keycode = 0, max_keycode = 0;
    if (!XDisplayKeycodes(helper_disp, &min_keycode, &max_keycode)) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: XDisplayKeycodes() failed!\n",
                __FUNCTION__, __LINE__);
        return 0;
    }

    size_t unused_keycodes_count = 0;

    for (KeyCode keycode = max_keycode; keycode >= min_keycode; keycode--) {
        int keysyms_per_keycode = 0;
        KeySym *keycode_keysyms = XGetKeyboardMapping(helper_disp, keycode, 1, &keysyms_per_keycode);
        int used = false;

        for (int i = 0; i < keysyms_per_keycode; i++) {
            if (keycode_keysyms[i] != NoSymbol) {
                used = true;
                break;
            }
        }

        if (!XFree(keycode_keysyms)) {
            logger(LOG_LEVEL_ERROR, "%s [%u]: XFree() failed!\n",
                    __FUNCTION__, __LINE__);
            return 0;
        }

        if (!used) {
            return keycode;
        }
    }

    return 0;
}

int post_keysym(KeySym keysym, KeyCode keycode) {
    if (keysym == NoSymbol) {
        return UIOHOOK_SUCCESS;
    }

    KeySym keysyms[4] = { keysym, keysym, keysym, keysym }; // Use the same KeySym for 4 shift levels
    int result = XChangeKeyboardMapping(helper_disp, keycode, 4, keysyms, 1);
    if (result != Success) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: XChangeKeyboardMapping() failed! (%d)\n",
                __FUNCTION__, __LINE__, result);
        return UIOHOOK_FAILURE;
    }

    XSync(helper_disp, True);

    struct timespec ts = {
        .tv_sec = post_text_delay / 1000000000,
        .tv_nsec = post_text_delay % 1000000000
    };

    nanosleep(&ts, NULL);

    if (!XTestFakeKeyEvent(helper_disp, keycode, true, 0)) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: XTestFakeKeyEvent() failed!\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_FAILURE;
    }

    XSync(helper_disp, True);

    if (!XTestFakeKeyEvent(helper_disp, keycode, false, 0)) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: XTestFakeKeyEvent() failed!\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_FAILURE;
    }

    XSync(helper_disp, True);

    nanosleep(&ts, NULL);

    return UIOHOOK_SUCCESS;
}

int hook_post_text(const uint16_t * const text) {
    if (text == NULL) {
        return UIOHOOK_ERROR_NULL;
    }

    if (helper_disp == NULL) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: XDisplay helper_disp is unavailable!\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_ERROR_X_OPEN_DISPLAY;
    }

    XLockDisplay(helper_disp);

    size_t count = 0;

    for (int i = 0; text[i] != 0; i++) {
        count++;
    }

    KeyCode unused_keycode = find_unused_keycode();

    if (unused_keycode == 0) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: Cannot find an unused key code!\n",
                __FUNCTION__, __LINE__);

        XUnlockDisplay(helper_disp);
        return UIOHOOK_FAILURE;
    }

    size_t keysym_count = 0;
    KeySym *keysyms = map_to_keysyms(text, count, &keysym_count);

    int status = UIOHOOK_SUCCESS;

    for (size_t i = 0; i < keysym_count; i++) {
        if (post_keysym(keysyms[i], unused_keycode) != UIOHOOK_SUCCESS) {
            status = UIOHOOK_FAILURE;
            break;
        }
    }

    free(keysyms);

    KeySym keysym = NoSymbol;
    int result = XChangeKeyboardMapping(helper_disp, unused_keycode, 1, &keysym, 1);
    if (result != Success) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: XChangeKeyboardMapping() failed! (%d)\n",
                __FUNCTION__, __LINE__, result);
        return UIOHOOK_FAILURE;
    }

    XSync(helper_disp, True);
    XUnlockDisplay(helper_disp);

    return status;
}
