#include <limits.h>
#include <stdlib.h>
#include <wchar.h>

#include "dispatch_event.h"
#include "input_helper.h"
#include "logger.h"

#define WHEEL_DELTA 120

typedef struct _mouse_click {
    uint16_t count;
    uint64_t time;
    uint16_t button;
} mouse_click;
static mouse_click click = {
    .count = 0,
    .time = 0,
    .button = MOUSE_NOBUTTON
};

// Virtual event pointer.
static uiohook_event uio_event;

// Event dispatch callback.
static dispatcher_t dispatch = NULL;
static void *dispatch_data = NULL;


static bool key_typed_enabled = false;

bool hook_is_key_typed_enabled() {
    return key_typed_enabled;
}

void hook_set_key_typed_enabled(bool enabled) {
    key_typed_enabled = enabled;
}

void hook_set_dispatch_proc(dispatcher_t dispatch_proc, void *user_data) {
    logger(LOG_LEVEL_DEBUG, "%s [%u]: Setting new dispatch callback to %#p.\n",
            __FUNCTION__, __LINE__, dispatch_proc);

    dispatch = dispatch_proc;
    dispatch_data = user_data;
}


// Send out an event if a dispatcher was set.
static void dispatch_event(uiohook_event *const uio_event) {
    if (dispatch != NULL) {
        logger(LOG_LEVEL_DEBUG, "%s [%u]: Dispatching event type %u.\n",
                __FUNCTION__, __LINE__, uio_event->type);

        dispatch(uio_event, dispatch_data);
    } else {
        logger(LOG_LEVEL_WARN, "%s [%u]: No dispatch callback set!\n",
                __FUNCTION__, __LINE__);
    }
}

bool dispatch_hook_enabled(uint64_t timestamp) {
    bool consumed = false;

    // Populate the hook start event.
    uio_event.time = timestamp;
    uio_event.type = EVENT_HOOK_ENABLED;
    uio_event.mask = 0x00;

    // Fire the hook start event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_CONSUMED;

    return consumed;
}

bool dispatch_hook_disabled(uint64_t timestamp) {
    bool consumed = false;

    // Populate the hook stop event.
    uio_event.time = timestamp;
    uio_event.type = EVENT_HOOK_DISABLED;
    uio_event.mask = 0x00;

    // Fire the hook stop event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_CONSUMED;

    return consumed;
}

bool dispatch_key_press(uint64_t timestamp, XKeyPressedEvent * const x_event) {
    bool consumed = false;

    uint16_t uiocode = keycode_to_uiocode(x_event->keycode);

    if      (uiocode == VC_SHIFT_L)     { set_modifier_mask(MASK_SHIFT_L);     }
    else if (uiocode == VC_SHIFT_R)     { set_modifier_mask(MASK_SHIFT_R);     }
    else if (uiocode == VC_CONTROL_L)   { set_modifier_mask(MASK_CTRL_L);      }
    else if (uiocode == VC_CONTROL_R)   { set_modifier_mask(MASK_CTRL_R);      }
    else if (uiocode == VC_ALT_L)       { set_modifier_mask(MASK_ALT_L);       }
    else if (uiocode == VC_ALT_R)       { set_modifier_mask(MASK_ALT_R);       }
    else if (uiocode == VC_META_L)      { set_modifier_mask(MASK_META_L);      }
    else if (uiocode == VC_META_R)      { set_modifier_mask(MASK_META_R);      }
    else if (uiocode == VC_NUM_LOCK)    { set_modifier_mask(MASK_NUM_LOCK);    }
    else if (uiocode == VC_CAPS_LOCK)   { set_modifier_mask(MASK_CAPS_LOCK);   }
    else if (uiocode == VC_SCROLL_LOCK) { set_modifier_mask(MASK_SCROLL_LOCK); }

    // Populate key pressed event.
    uio_event.time = timestamp;
    uio_event.type = EVENT_KEY_PRESSED;
    uio_event.mask = get_modifiers();
    if (x_event->send_event) {
        uio_event.mask |= MASK_EMULATED;
    }

    uio_event.data.keyboard.keycode = uiocode;
    uio_event.data.keyboard.rawcode = x_event->keycode;
    uio_event.data.keyboard.keychar = CHAR_UNDEFINED;

    logger(LOG_LEVEL_DEBUG, "%s [%u]: Key %#X pressed. (%#X)\n",
            __FUNCTION__, __LINE__,
            uio_event.data.keyboard.keycode, uio_event.data.keyboard.rawcode);

    // Fire key pressed event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_CONSUMED;

    // XRecord provides a copy of the event stream, so a consumed key press is still typed.
    if (key_typed_enabled) {
        KeySym keysym = 0x00;

        uint16_t surrogate[2] = {};
        size_t count = event_to_unicode(x_event, surrogate, sizeof(surrogate) / sizeof(uint16_t), &keysym);

        for (unsigned int i = 0; i < count; i++) {
            // Populate key typed event.
            uio_event.time = x_event->serial;
            uio_event.type = EVENT_KEY_TYPED;
            uio_event.mask = get_modifiers();
            if (x_event->send_event) {
                uio_event.mask |= MASK_EMULATED;
            }

            uio_event.data.keyboard.keycode = uiocode;
            uio_event.data.keyboard.rawcode = keysym;
            uio_event.data.keyboard.keychar = surrogate[i];

            logger(LOG_LEVEL_DEBUG, "%s [%u]: Key %#X typed. (%lc)\n",
                    __FUNCTION__, __LINE__,
                    uio_event.data.keyboard.keycode,
                    (wint_t) uio_event.data.keyboard.keychar);

            // Fire key typed event.
            dispatch_event(&uio_event);
            consumed = uio_event.mask & MASK_CONSUMED;
        }
    }

    return consumed;
}

bool dispatch_key_release(uint64_t timestamp, XKeyReleasedEvent * const x_event) {
    bool consumed = false;

    uint16_t uiocode = keycode_to_uiocode(x_event->keycode);

    if      (uiocode == VC_SHIFT_L)   { unset_modifier_mask(MASK_SHIFT_L); }
    else if (uiocode == VC_SHIFT_R)   { unset_modifier_mask(MASK_SHIFT_R); }
    else if (uiocode == VC_CONTROL_L) { unset_modifier_mask(MASK_CTRL_L);  }
    else if (uiocode == VC_CONTROL_R) { unset_modifier_mask(MASK_CTRL_R);  }
    else if (uiocode == VC_ALT_L)     { unset_modifier_mask(MASK_ALT_L);   }
    else if (uiocode == VC_ALT_R)     { unset_modifier_mask(MASK_ALT_R);   }
    else if (uiocode == VC_META_L)    { unset_modifier_mask(MASK_META_L);  }
    else if (uiocode == VC_META_R)    { unset_modifier_mask(MASK_META_R);  }
    // Caps Lock, Num Lock, and Scroll Lock should not be unset as they are already
    // handled when setting the modifier mask based on the X11 event.

    // Populate key released event.
    uio_event.time = timestamp;
    uio_event.type = EVENT_KEY_RELEASED;
    uio_event.mask = get_modifiers();
    if (x_event->send_event) {
        uio_event.mask |= MASK_EMULATED;
    }

    uio_event.data.keyboard.keycode = uiocode;
    uio_event.data.keyboard.rawcode = x_event->keycode;
    uio_event.data.keyboard.keychar = CHAR_UNDEFINED;

    logger(LOG_LEVEL_DEBUG, "%s [%u]: Key %#X released. (%#X)\n",
            __FUNCTION__, __LINE__,
            uio_event.data.keyboard.keycode, uio_event.data.keyboard.rawcode);

    // Fire key released event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_CONSUMED;

    return consumed;
}

static bool dispatch_mouse_wheel_rotated(uint64_t timestamp, XButtonEvent * const x_event) {
    bool consumed = false;

    // Reset the click count and previous button.
    click.count = 0;
    click.button = MOUSE_NOBUTTON;

    // Populate mouse wheel event.
    uio_event.time = timestamp;
    uio_event.type = EVENT_MOUSE_WHEEL;
    uio_event.mask = get_modifiers();
    if (x_event->send_event) {
        uio_event.mask |= MASK_EMULATED;
    }

    uio_event.data.wheel.x = x_event->x_root;
    uio_event.data.wheel.y = x_event->y_root;

    uint8_t count;
    screen_data *screens = hook_create_screen_info(&count);
    if (count > 1) {
        uio_event.data.wheel.x -= screens[0].x;
        uio_event.data.wheel.y -= screens[0].y;
    }

    if (screens != NULL) {
        free(screens);
    }

    /* X11 does not have an API call for acquiring the mouse scroll type. This maybe part of the XInput2 (XI2)
     * extension but I will wont know until it is available on my platform. For the time being we will just use the
     * unit scroll value. */
    uio_event.data.wheel.type = WHEEL_UNIT_SCROLL;

    /* Some scroll wheel properties are available via the new XInput2 (XI2) extension. Unfortunately the extension is
     * not available on my development platform at this time. For the time being we will just use the Windows default
     * value of 3. */
    uio_event.data.wheel.delta = WHEEL_DELTA;
    if (x_event->button == WheelDown || x_event->button == WheelRight) {
        // Wheel Rotated Up and Towards.
        uio_event.data.wheel.rotation = -3 * uio_event.data.wheel.delta;
    } else { // event.button == WheelUp || event.button == WheelLeft
        // Wheel Rotated Down and Away.
        uio_event.data.wheel.rotation = 3 * uio_event.data.wheel.delta;
    }

    if (x_event->button == WheelUp || x_event->button == WheelDown) {
        // Wheel Rotated Up or Down.
        uio_event.data.wheel.direction = WHEEL_VERTICAL_DIRECTION;
    } else { // event.button == WheelLeft || event.button == WheelRight
        // Wheel Rotated Left or Right.
        uio_event.data.wheel.direction = WHEEL_HORIZONTAL_DIRECTION;
    }

    logger(LOG_LEVEL_DEBUG, "%s [%u]: Mouse wheel %i / %u of type %u in the %u direction at %u, %u.\n",
            __FUNCTION__, __LINE__,
            uio_event.data.wheel.rotation, uio_event.data.wheel.delta,
            uio_event.data.wheel.type, uio_event.data.wheel.direction,
            uio_event.data.wheel.x, uio_event.data.wheel.y);

    // Fire mouse wheel event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_CONSUMED;

    return consumed;
}

static bool dispatch_mouse_button_pressed(uint64_t timestamp, XButtonPressedEvent * const x_event) {
    bool consumed = false;

    switch (x_event->button) {
        case Button1:
            x_event->button = MOUSE_BUTTON1;
            set_modifier_mask(MASK_BUTTON1);
            break;

        case Button2:
            x_event->button = MOUSE_BUTTON2;
            set_modifier_mask(MASK_BUTTON2);
            break;

        case Button3:
            x_event->button = MOUSE_BUTTON3;
            set_modifier_mask(MASK_BUTTON3);
            break;

        case XButton1:
            x_event->button = MOUSE_BUTTON4;
            set_modifier_mask(MASK_BUTTON5);
            break;

        case XButton2:
            x_event->button = MOUSE_BUTTON5;
            set_modifier_mask(MASK_BUTTON5);
            break;

        default:
            if (x_event->button > XButton2) {
                // Do not set modifier masks past button MASK_BUTTON5.
                x_event->button = MOUSE_BUTTON5 + (x_event->button - XButton2);
            } else {
                // Something screwed up, default to MOUSE_NOBUTTON
                x_event->button = MOUSE_NOBUTTON;
            }
    }

    // Track the number of clicks, the button must match the previous button.
    if (x_event->button == click.button && x_event->serial - click.time <= hook_get_multi_click_time()) {
        if (click.count < UINT16_MAX) {
            click.count++;
        } else {
            logger(LOG_LEVEL_WARN, "%s [%u]: Click count overflow detected!\n",
                    __FUNCTION__, __LINE__);
        }
    } else {
        // Reset the click count.
        click.count = 1;

        // Set the last clicked button.
        click.button = x_event->button;
    }

    // Save this events time to calculate multi-clicks.
    click.time = x_event->serial;

    // Populate mouse pressed event.
    uio_event.time = timestamp;
    uio_event.type = EVENT_MOUSE_PRESSED;
    uio_event.mask = get_modifiers();
    if (x_event->send_event) {
        uio_event.mask |= MASK_EMULATED;
    }

    uio_event.data.mouse.button = x_event->button;
    uio_event.data.mouse.clicks = click.count;
    uio_event.data.mouse.x = x_event->x_root;
    uio_event.data.mouse.y = x_event->y_root;

    // FIXME There is something still broken about this.
    uint8_t count;
    screen_data *screens = hook_create_screen_info(&count);
    if (count > 1) {
        uio_event.data.mouse.x -= screens[0].x;
        uio_event.data.mouse.y -= screens[0].y;
    }

    if (screens != NULL) {
        free(screens);
    }

    logger(LOG_LEVEL_DEBUG, "%s [%u]: Button %u  pressed %u time(s). (%u, %u)\n",
            __FUNCTION__, __LINE__,
            uio_event.data.mouse.button, uio_event.data.mouse.clicks,
            uio_event.data.mouse.x, uio_event.data.mouse.y);

    // Fire mouse pressed event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_CONSUMED;

    return consumed;
}

bool dispatch_mouse_press(uint64_t timestamp, XButtonEvent * const x_event) {
    bool consumed = false;
    x_event->button = button_map_lookup(x_event->button);

    switch (x_event->button) {
        case WheelUp:
        case WheelDown:
        case WheelLeft:
        case WheelRight:
            consumed = dispatch_mouse_wheel_rotated(timestamp, (XButtonEvent *) x_event);
            break;

        default:
            consumed = dispatch_mouse_button_pressed(timestamp, (XButtonPressedEvent *) x_event);
            break;
    }

    return consumed;
}

static bool dispatch_mouse_button_released(uint64_t timestamp, XButtonReleasedEvent * const x_event) {
    bool consumed = false;

    switch (x_event->button) {
        case Button1:
            x_event->button = MOUSE_BUTTON1;
            unset_modifier_mask(MASK_BUTTON1);
            break;

        case Button2:
            x_event->button = MOUSE_BUTTON2;
            unset_modifier_mask(MASK_BUTTON2);
            break;

        case Button3:
            x_event->button = MOUSE_BUTTON3;
            unset_modifier_mask(MASK_BUTTON3);
            break;

        case XButton1:
            x_event->button = MOUSE_BUTTON4;
            unset_modifier_mask(MASK_BUTTON5);
            break;

        case XButton2:
            x_event->button = MOUSE_BUTTON5;
            unset_modifier_mask(MASK_BUTTON5);
            break;

        default:
            if (x_event->button > XButton2) {
                // Do not set modifier masks past button MASK_BUTTON5.
                x_event->button = MOUSE_BUTTON5 + (x_event->button - XButton2);
            } else {
                // Something screwed up, default to MOUSE_NOBUTTON
                x_event->button = MOUSE_NOBUTTON;
            }
    }

    // Populate mouse released event.
    uio_event.time = timestamp;
    uio_event.type = EVENT_MOUSE_RELEASED;
    uio_event.mask = get_modifiers();
    if (x_event->send_event) {
        uio_event.mask |= MASK_EMULATED;
    }

    uio_event.data.mouse.button = x_event->button;
    uio_event.data.mouse.clicks = click.count;
    uio_event.data.mouse.x = x_event->x_root;
    uio_event.data.mouse.y = x_event->y_root;

    uint8_t count;
    screen_data *screens = hook_create_screen_info(&count);
    if (count > 1) {
        uio_event.data.mouse.x -= screens[0].x;
        uio_event.data.mouse.y -= screens[0].y;
    }

    if (screens != NULL) {
        free(screens);
    }

    logger(LOG_LEVEL_DEBUG, "%s [%u]: Button %u released %u time(s). (%u, %u)\n",
            __FUNCTION__, __LINE__,
            uio_event.data.mouse.button, uio_event.data.mouse.clicks,
            uio_event.data.mouse.x, uio_event.data.mouse.y);

    // Fire mouse released event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_CONSUMED;

    return consumed;
}

static bool dispatch_mouse_button_clicked(uint64_t timestamp, XButtonEvent * const x_event) {
    bool consumed = false;

    // Populate mouse clicked event.
    uio_event.time = timestamp;
    uio_event.type = EVENT_MOUSE_CLICKED;
    uio_event.mask = get_modifiers();
    if (x_event->send_event) {
        uio_event.mask |= MASK_EMULATED;
    }

    uio_event.data.mouse.button = x_event->button;
    uio_event.data.mouse.clicks = click.count;
    uio_event.data.mouse.x = x_event->x_root;
    uio_event.data.mouse.y = x_event->y_root;

    uint8_t count;
    screen_data *screens = hook_create_screen_info(&count);
    if (count > 1) {
        uio_event.data.mouse.x -= screens[0].x;
        uio_event.data.mouse.y -= screens[0].y;
    }

    if (screens != NULL) {
        free(screens);
    }

    logger(LOG_LEVEL_DEBUG, "%s [%u]: Button %u clicked %u time(s). (%u, %u)\n",
            __FUNCTION__, __LINE__,
            uio_event.data.mouse.button, uio_event.data.mouse.clicks,
            uio_event.data.mouse.x, uio_event.data.mouse.y);

    // Fire mouse clicked event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_CONSUMED;

    return consumed;
}

bool dispatch_mouse_release(uint64_t timestamp, XButtonEvent * const x_event) {
    bool consumed = false;

    x_event->button = button_map_lookup(x_event->button);
    switch (x_event->button) {
        case WheelUp:
        case WheelDown:
        case WheelLeft:
        case WheelRight:
            return consumed;
    }

    consumed = dispatch_mouse_button_released(timestamp, (XButtonReleasedEvent *) x_event);
    bool is_dragged = (bool) (get_modifiers() & 0x1F00);

    // XRecord provides a copy of the event stream, so a consumed release is still a click.
    if (!is_dragged) {
        dispatch_mouse_button_clicked(timestamp, x_event);
    }

    // Reset the number of clicks.
    // FIXME
    if (x_event->button == click.button && (x_event->serial - click.time) > hook_get_multi_click_time()) {
        // Reset the click count.
        click.count = 0;
    }

    return consumed;
}

bool dispatch_mouse_move(uint64_t timestamp, XMotionEvent * const x_event) {
    bool consumed = false;

    // Reset the click count.
    if (click.count != 0 && x_event->serial - click.time > hook_get_multi_click_time()) {
        click.count = 0;
    }

    // Populate mouse move event.
    uio_event.time = timestamp;
    uio_event.mask = get_modifiers();
    if (x_event->send_event) {
        uio_event.mask |= MASK_EMULATED;
    }

    // Check the upper half of virtual modifiers for non-zero values and set the mouse
    // dragged flag.  The last 3 bits are reserved for lock masks.
    bool is_dragged = (bool) (get_modifiers() & 0x1F00);
    if (is_dragged) {
        // Create Mouse Dragged event.
        uio_event.type = EVENT_MOUSE_DRAGGED;
    } else {
        // Create a Mouse Moved event.
        uio_event.type = EVENT_MOUSE_MOVED;
    }

    uio_event.data.mouse.button = MOUSE_NOBUTTON;
    uio_event.data.mouse.clicks = click.count;
    uio_event.data.mouse.x = x_event->x_root;
    uio_event.data.mouse.y = x_event->y_root;

    uint8_t count;
    screen_data *screens = hook_create_screen_info(&count);
    if (count > 1) {
        uio_event.data.mouse.x -= screens[0].x;
        uio_event.data.mouse.y -= screens[0].y;
    }

    if (screens != NULL) {
        free(screens);
    }

    logger(LOG_LEVEL_DEBUG, "%s [%u]: Mouse %s to %i, %i. (%#X)\n",
            __FUNCTION__, __LINE__,
            is_dragged ? "dragged" : "moved",
            uio_event.data.mouse.x, uio_event.data.mouse.y, uio_event.mask);

    // Fire mouse move event.
    dispatch_event(&uio_event);
    consumed = uio_event.mask & MASK_EMULATED;

    return consumed;
}
