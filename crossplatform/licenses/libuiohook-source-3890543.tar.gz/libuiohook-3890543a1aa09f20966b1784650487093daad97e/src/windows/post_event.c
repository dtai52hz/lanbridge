#include <stdio.h>
#include <uiohook.h>
#include <windows.h>

#include "input_helper.h"
#include "logger.h"
#include "monitor_helper.h"

// Some buggy versions of MinGW and MSys do not include these constants in winuser.h.
#ifndef MAPVK_VK_TO_VSC
#define MAPVK_VK_TO_VSC         0
#define MAPVK_VSC_TO_VK         1
#define MAPVK_VK_TO_CHAR        2
#define MAPVK_VSC_TO_VK_EX      3
#endif
// Some buggy versions of MinGW and MSys only define this value for Windows
// versions >= 0x0600 (Windows Vista) when it should be 0x0500 (Windows 2000).
#ifndef MAPVK_VK_TO_VSC_EX
#define MAPVK_VK_TO_VSC_EX      4
#endif

#ifndef KEYEVENTF_SCANCODE
#define KEYEVENTF_EXTENDEDKEY   0x0001
#define KEYEVENTF_KEYUP         0x0002
#define KEYEVENTF_UNICODE       0x0004
#define KEYEVENTF_SCANCODE      0x0008
#endif

#ifndef KEYEVENTF_KEYDOWN
#define KEYEVENTF_KEYDOWN       0x0000
#endif

#define MAX_WINDOWS_COORD_VALUE ((1 << 16) - 1)

typedef struct {
    LONG x;
    LONG y;
} normalized_coordinates;

static LONG get_absolute_coordinate(LONG coordinate, int screen_size) {
    return MulDiv((int) coordinate, MAX_WINDOWS_COORD_VALUE, screen_size) + MAX_WINDOWS_COORD_VALUE / (screen_size * 2);
}

static normalized_coordinates normalize_coordinates(LONG x, LONG y) {
    uint16_t screen_width  = GetSystemMetrics(SM_CXVIRTUALSCREEN);
    uint16_t screen_height = GetSystemMetrics(SM_CYVIRTUALSCREEN);

    largest_negative_coordinates lnc = get_largest_negative_coordinates();

    x += abs(lnc.left);
    y += abs(lnc.top);

    normalized_coordinates nc = {
            .x = get_absolute_coordinate(x, screen_width),
            .y = get_absolute_coordinate(y, screen_height)
    };

    return nc;
}

static int map_keyboard_event(uiohook_event * const event, INPUT * const input) {
    input->type = INPUT_KEYBOARD;

    switch (event->type) {
        case EVENT_KEY_PRESSED:
            input->ki.dwFlags = KEYEVENTF_KEYDOWN;
            break;

        case EVENT_KEY_RELEASED:
            input->ki.dwFlags = KEYEVENTF_KEYUP;
            break;

        default:
            logger(LOG_LEVEL_DEBUG, "%s [%u]: Invalid event for keyboard event mapping: %#X.\n",
                    __FUNCTION__, __LINE__, event->type);
            return UIOHOOK_FAILURE;
    }

    input->ki.wVk = (WORD) uiocode_to_keycode(event->data.keyboard.keycode);
    if (input->ki.wVk == 0x0000) {
        logger(LOG_LEVEL_WARN, "%s [%u]: Unable to lookup scancode: %li\n",
                __FUNCTION__, __LINE__, event->data.keyboard.keycode);
        return UIOHOOK_FAILURE;
    }

    input->ki.wScan = MapVirtualKeyW(input->ki.wVk, MAPVK_VK_TO_VSC_EX);
    input->ki.dwFlags |= KEYEVENTF_SCANCODE;

    if (HIBYTE(input->ki.wScan)) {
        input->ki.dwFlags |= KEYEVENTF_EXTENDEDKEY;
    } else {
        switch (event->data.keyboard.keycode) {
            case VC_UP:
            case VC_DOWN:
            case VC_LEFT:
            case VC_RIGHT:
            case VC_HOME:
            case VC_END:
            case VC_PAGE_UP:
            case VC_PAGE_DOWN:
            case VC_INSERT:
            case VC_DELETE:
            case VC_KP_ENTER:
                input->ki.dwFlags |= KEYEVENTF_EXTENDEDKEY;
                break;
        }
    }

    return UIOHOOK_SUCCESS;
}

static int map_mouse_event(uiohook_event * const event, INPUT * const input) {
    input->type = INPUT_MOUSE;
    input->mi.mouseData = 0;
    input->mi.dwExtraInfo = 0;
    input->mi.time = 0; // GetSystemTime();

    if (event->type != EVENT_MOUSE_WHEEL) {
        LONG x = event->data.mouse.x;
        LONG y = event->data.mouse.y;

        if (event->type == EVENT_MOUSE_MOVED_RELATIVE || event->type == EVENT_MOUSE_DRAGGED_RELATIVE) {
            POINT p;
            if (GetCursorPos(&p)) {
                x += p.x;
                y += p.y;
            }
        }

        normalized_coordinates nc = normalize_coordinates(x, y);

        input->mi.dy = nc.y;
        input->mi.dx = nc.x;
    }

    switch (event->type) {
        case EVENT_MOUSE_PRESSED:
        case EVENT_MOUSE_PRESSED_IGNORE_COORDS:
            if (event->data.mouse.button == MOUSE_NOBUTTON) {
                logger(LOG_LEVEL_WARN, "%s [%u]: No button specified for mouse pressed event!\n",
                        __FUNCTION__, __LINE__);
                return UIOHOOK_FAILURE;
            } else if (event->data.mouse.button == MOUSE_BUTTON1) {
                input->mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
            } else if (event->data.mouse.button == MOUSE_BUTTON2) {
                input->mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;
            } else if (event->data.mouse.button == MOUSE_BUTTON3) {
                input->mi.dwFlags = MOUSEEVENTF_MIDDLEDOWN;
            } else {
                input->mi.dwFlags = MOUSEEVENTF_XDOWN;
                if (event->data.mouse.button == MOUSE_BUTTON4) {
                    input->mi.mouseData = XBUTTON1;
                } else if (event->data.mouse.button == MOUSE_BUTTON5) {
                    input->mi.mouseData = XBUTTON2;
                } else {
                    input->mi.mouseData = event->data.mouse.button - 3;
                }
            }

            if (event->type == EVENT_MOUSE_PRESSED) {
                // We need to move the mouse to the correct location prior to clicking.
                event->type = EVENT_MOUSE_MOVED;
                // TODO Remember to check the status here.
                hook_post_event(event);
                event->type = EVENT_MOUSE_PRESSED;
            }

            break;

        case EVENT_MOUSE_RELEASED:
        case EVENT_MOUSE_RELEASED_IGNORE_COORDS:
            if (event->data.mouse.button == MOUSE_NOBUTTON) {
                logger(LOG_LEVEL_WARN, "%s [%u]: No button specified for mouse released event!\n",
                        __FUNCTION__, __LINE__);
                return UIOHOOK_FAILURE;
            } else if (event->data.mouse.button == MOUSE_BUTTON1) {
                input->mi.dwFlags = MOUSEEVENTF_LEFTUP;
            } else if (event->data.mouse.button == MOUSE_BUTTON2) {
                input->mi.dwFlags = MOUSEEVENTF_RIGHTUP;
            } else if (event->data.mouse.button == MOUSE_BUTTON3) {
                input->mi.dwFlags = MOUSEEVENTF_MIDDLEUP;
            } else {
                input->mi.dwFlags = MOUSEEVENTF_XUP;
                if (event->data.mouse.button == MOUSE_BUTTON4) {
                    input->mi.mouseData = XBUTTON1;
                } else if (event->data.mouse.button == MOUSE_BUTTON5) {
                    input->mi.mouseData = XBUTTON2;
                } else {
                    input->mi.mouseData = event->data.mouse.button - 3;
                }
            }

            if (event->type == EVENT_MOUSE_RELEASED) {
                // We need to move the mouse to the correct location prior to clicking.
                event->type = EVENT_MOUSE_MOVED;
                // TODO Remember to check the status here.
                hook_post_event(event);
                event->type = EVENT_MOUSE_RELEASED;
            }

            break;

        case EVENT_MOUSE_WHEEL:
            bool is_reversed = is_scroll_direction_reversed();

            if (event->data.wheel.direction == WHEEL_HORIZONTAL_DIRECTION) {
                input->mi.dwFlags = (DWORD)MOUSEEVENTF_HWHEEL;
                input->mi.mouseData = (DWORD)(event->data.wheel.rotation * (is_reversed ? 1 : -1)); // The direction should be reversed by default
            } else {
                input->mi.dwFlags = (DWORD)MOUSEEVENTF_WHEEL;
                input->mi.mouseData = (DWORD)(event->data.wheel.rotation * (is_reversed ? -1 : 1));
            }
            break;

        case EVENT_MOUSE_MOVED:
        case EVENT_MOUSE_MOVED_RELATIVE:
        case EVENT_MOUSE_DRAGGED:
        case EVENT_MOUSE_DRAGGED_RELATIVE:
            input->mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK;
            break;

        default:
            logger(LOG_LEVEL_DEBUG, "%s [%u]: Invalid event for mouse event mapping: %#X.\n",
                    __FUNCTION__, __LINE__, event->type);
            return UIOHOOK_FAILURE;
    }

    return UIOHOOK_SUCCESS;
}

int hook_post_event(uiohook_event * const event) {
    return hook_post_events(event, 1);
}

int hook_post_events(uiohook_event * const events, uint32_t size) {
    if (events == NULL) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: Not simulating any events as the events are null.\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_ERROR_NULL;
    }

    if (size == 0) {
        logger(LOG_LEVEL_WARN, "%s [%u]: Not simulating any events as the size is 0.\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_SUCCESS;
    }

    INPUT *inputs = (INPUT *) calloc(size, sizeof(INPUT));
    if (inputs == NULL) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: Failed to allocate memory: calloc!\n",
                __FUNCTION__, __LINE__);
        return UIOHOOK_ERROR_OUT_OF_MEMORY;
    }

    int status = UIOHOOK_SUCCESS;

    for (SIZE_T i = 0; i < size && status == UIOHOOK_SUCCESS; i++) {
        uiohook_event *event = events + i;
        INPUT *input = inputs + i;

        logger(LOG_LEVEL_DEBUG, "%s [%u]: Posting an event of type: %#X.\n",
                __FUNCTION__, __LINE__, event->type);

        switch (event->type) {
            case EVENT_KEY_PRESSED:
            case EVENT_KEY_RELEASED:
                status = map_keyboard_event(event, input);
                break;

            case EVENT_MOUSE_PRESSED:
            case EVENT_MOUSE_PRESSED_IGNORE_COORDS:
            case EVENT_MOUSE_RELEASED:
            case EVENT_MOUSE_RELEASED_IGNORE_COORDS:
            case EVENT_MOUSE_MOVED:
            case EVENT_MOUSE_MOVED_RELATIVE:
            case EVENT_MOUSE_DRAGGED:
            case EVENT_MOUSE_DRAGGED_RELATIVE:
            case EVENT_MOUSE_WHEEL:
                status = map_mouse_event(event, input);
                break;

            case EVENT_KEY_TYPED:
            case EVENT_MOUSE_CLICKED:

            case EVENT_HOOK_ENABLED:
            case EVENT_HOOK_DISABLED:

            default:
                logger(LOG_LEVEL_DEBUG, "%s [%u]: Ignoring post event of type: %#X.\n",
                        __FUNCTION__, __LINE__, event->type);
                status = UIOHOOK_FAILURE;
                break;
        }
    }

    if (status == UIOHOOK_SUCCESS && !SendInput(size, inputs, sizeof(INPUT))) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: SendInput() failed! (%#lX)\n",
                __FUNCTION__, __LINE__, (unsigned long) GetLastError());
        status = UIOHOOK_FAILURE;
    }

    free(inputs);

    return status;
}

int hook_post_text(const uint16_t * const text) {
    if (text == NULL) {
        return UIOHOOK_ERROR_NULL;
    }

    int status = UIOHOOK_SUCCESS;

    size_t count = 0;

    for (int i = 0; text[i] != 0; i++) {
        count += 2;
    }

    INPUT *input = (INPUT*)calloc(count, sizeof(INPUT));

    if (input == NULL) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: failed to allocate memory: calloc!\n",
            __FUNCTION__, __LINE__);
        return UIOHOOK_ERROR_OUT_OF_MEMORY;
    }

    for (int i = 0; i < count - 1; i += 2) {
        WORD character = (WORD)text[i / 2];

        input[i].type = INPUT_KEYBOARD;
        input[i].ki.wVk = 0;
        input[i].ki.wScan = character;
        input[i].ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYDOWN;

        if (character < 0xD800 || character > 0xDFFF) { // Normal character
            input[i + 1].type = INPUT_KEYBOARD;
            input[i + 1].ki.wVk = 0;
            input[i + 1].ki.wScan = character;
            input[i + 1].ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;
        } else { // Surrogate pair, both characters must first be pressed, and then released
            WORD nextCharacter = (WORD)text[i / 2 + 1]; // Assume that the character array is well-formed UTF-16

            input[i + 1].type = INPUT_KEYBOARD;
            input[i + 1].ki.wVk = 0;
            input[i + 1].ki.wScan = nextCharacter;
            input[i + 1].ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYDOWN;

            input[i + 2].type = INPUT_KEYBOARD;
            input[i + 2].ki.wVk = 0;
            input[i + 2].ki.wScan = character;
            input[i + 2].ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;

            input[i + 3].type = INPUT_KEYBOARD;
            input[i + 3].ki.wVk = 0;
            input[i + 3].ki.wScan = nextCharacter;
            input[i + 3].ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;

            i += 2;
        }
    }

    if (!SendInput(count, input, sizeof(INPUT))) {
        logger(LOG_LEVEL_ERROR, "%s [%u]: SendInput() failed! (%#lX)\n",
            __FUNCTION__, __LINE__, (unsigned long)GetLastError());
        status = UIOHOOK_FAILURE;
    }

    free(input);

    return UIOHOOK_SUCCESS;
}
